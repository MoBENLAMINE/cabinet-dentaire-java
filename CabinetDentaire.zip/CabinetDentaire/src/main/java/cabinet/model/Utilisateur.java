package cabinet.model;

import java.io.Serializable;

/**
 * Classe ABSTRAITE : on ne peut pas faire "new Utilisateur(...)".
 * Elle regroupe ce qui est commun a l'Administrateur et au Patient (heritage).
 */
public abstract class Utilisateur implements Serializable {

    // Encapsulation : attributs prives, acces par getters/setters
    private String login;
    private String pwd;

    public Utilisateur(String login, String pwd) {
        this.login = login;
        this.pwd = pwd;
    }

    /** Verifie le login et le mot de passe saisis dans la fenetre d'accueil. */
    public boolean authentifier(String login, String pwd) {
        return this.login.equals(login) && this.pwd.equals(pwd);
    }

    /** Methode abstraite : chaque sous-classe donne SA reponse (polymorphisme). */
    public abstract String getRole();

    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getPwd() { return pwd; }
    public void setPwd(String pwd) { this.pwd = pwd; }
}
