package cabinet.model;

/**
 * INTERFACE : un "contrat". Toute classe qui l'implemente
 * doit savoir produire le texte de sa fiche (pour l'ecran, l'impression, le PDF).
 */
public interface Imprimable {
    String genererFiche();
}
