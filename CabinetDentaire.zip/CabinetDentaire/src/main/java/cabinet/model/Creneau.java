package cabinet.model;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

/** Une plage horaire dans le planning d'un dentiste. */
public class Creneau implements Serializable {

    // Constantes de classe (static final) : partagees par tous les objets
    public static final String NORMAL = "normal";
    public static final String URGENCE = "urgence";

    private int idCreneau;
    private LocalDate date;
    private LocalTime heureDebut;
    private LocalTime heureFin;
    private String type;        // NORMAL ou URGENCE
    private Dentiste dentiste;  // le creneau "reference un dentiste"

    public Creneau(int idCreneau, LocalDate date, LocalTime heureDebut, LocalTime heureFin,
                   String type, Dentiste dentiste) {
        this.idCreneau = idCreneau;
        this.date = date;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.type = type;
        this.dentiste = dentiste;
    }

    /** Constructeur par copie (vu en cours) : sert a creer un CreneauReserve. */
    public Creneau(Creneau c) {
        this(c.idCreneau, c.date, c.heureDebut, c.heureFin, c.type, c.dentiste);
    }

    /** Un creneau simple est toujours libre. CreneauReserve redefinit cette methode. */
    public boolean estLibre() { return true; }

    /** Vrai si la duree de l'acte tient dans le creneau. */
    public boolean contient(Acte acte) {
        return acte.getDuree() <= getDureeMinutes();
    }

    public long getDureeMinutes() {
        return Duration.between(heureDebut, heureFin).toMinutes();
    }

    public boolean estUrgence() { return URGENCE.equals(type); }

    @Override
    public String toString() { return date + " " + heureDebut + "-" + heureFin + " [" + type + "]"; }

    public int getIdCreneau() { return idCreneau; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public LocalTime getHeureDebut() { return heureDebut; }
    public void setHeureDebut(LocalTime heureDebut) { this.heureDebut = heureDebut; }
    public LocalTime getHeureFin() { return heureFin; }
    public void setHeureFin(LocalTime heureFin) { this.heureFin = heureFin; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public Dentiste getDentiste() { return dentiste; }
}
