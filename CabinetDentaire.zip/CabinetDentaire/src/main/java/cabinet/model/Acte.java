package cabinet.model;

import java.io.Serializable;

/** Un acte medical : detartrage, extraction, devitalisation... */
public class Acte implements Serializable {

    private int idActe;
    private String libelle;
    private int duree;     // en minutes
    private double tarif;  // en dirhams

    public Acte(int idActe, String libelle, int duree, double tarif) {
        this.idActe = idActe;
        this.libelle = libelle;
        this.duree = duree;
        this.tarif = tarif;
    }

    @Override
    public String toString() { return libelle + " (" + duree + " min, " + tarif + " DH)"; }

    public int getIdActe() { return idActe; }
    public String getLibelle() { return libelle; }
    public void setLibelle(String libelle) { this.libelle = libelle; }
    public int getDuree() { return duree; }
    public void setDuree(int duree) { this.duree = duree; }
    public double getTarif() { return tarif; }
    public void setTarif(double tarif) { this.tarif = tarif; }
}
