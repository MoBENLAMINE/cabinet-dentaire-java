package cabinet.model;

/** La secretaire du cabinet. Herite de Utilisateur (login, pwd, authentifier). */
public class Administrateur extends Utilisateur {

    public Administrateur(String login, String pwd) {
        super(login, pwd); // appelle le constructeur de la classe mere
    }

    @Override
    public String getRole() { return "ADMIN"; }

    public void validerRdv(RendezVous rdv) { rdv.valider(); }

    public void annulerRdv(RendezVous rdv) { rdv.annuler(); }

    // gererPatients(), gererDentistes(), gererActes(), gererCreneaux() :
    // ce sont les ecrans CRUD de la fenetre admin (JavaFX), qui appellent
    // les methodes ajouter/modifier/supprimer de la classe Cabinet.
}
