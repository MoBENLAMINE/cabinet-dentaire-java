package cabinet.model;

/** Un creneau sur lequel un rendez-vous a ete pris. Herite de Creneau. */
public class CreneauReserve extends Creneau {

    private RendezVous rendezVous;

    public CreneauReserve(Creneau c) {
        super(c); // on recopie date, heures, type et dentiste
    }

    /**
     * POLYMORPHISME : meme signature que Creneau.estLibre(), autre comportement.
     * Le creneau redevient libre si son rendez-vous est annule.
     */
    @Override
    public boolean estLibre() {
        return rendezVous == null || rendezVous.estAnnule();
    }

    public RendezVous getRendezVous() { return rendezVous; }
    public void setRendezVous(RendezVous rendezVous) { this.rendezVous = rendezVous; }
}
