package cabinet.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/** Un dentiste "possede" plusieurs creneaux (association 1 -> *). */
public class Dentiste implements Serializable {

    private int idDentiste;
    private String nom;
    private String prenom;
    private String specialite; // generaliste, orthodontiste, ...
    private List<Creneau> planning = new ArrayList<>();

    public Dentiste(int idDentiste, String nom, String prenom, String specialite) {
        this.idDentiste = idDentiste;
        this.nom = nom;
        this.prenom = prenom;
        this.specialite = specialite;
    }

    public List<Creneau> getPlanning() { return planning; }

    public void ajouterCreneau(Creneau c) { planning.add(c); }

    public void supprimerCreneau(Creneau c) { planning.remove(c); }

    /** Quand on reserve, le Creneau est remplace par un CreneauReserve. */
    public void remplacerCreneau(Creneau ancien, Creneau nouveau) {
        int i = planning.indexOf(ancien);
        if (i >= 0) planning.set(i, nouveau);
    }

    @Override
    public String toString() { return "Dr " + nom + " " + prenom + " - " + specialite; }

    public int getIdDentiste() { return idDentiste; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }
    public String getSpecialite() { return specialite; }
    public void setSpecialite(String specialite) { this.specialite = specialite; }
}
