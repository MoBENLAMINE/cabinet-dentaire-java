package cabinet.model;

import java.io.Serializable;
import java.time.LocalDate;

/** Reference un patient, un acte et un creneau reserve (associations). */
public class RendezVous implements Serializable, Imprimable {

    public static final String EN_ATTENTE = "En attente";
    public static final String VALIDE = "Valide";
    public static final String ANNULE = "Annule";

    private int idRdv;
    private LocalDate dateReservation; // jour ou le patient a reserve
    private LocalDate dateRdv;         // jour du rendez-vous
    private String etat;
    private Patient patient;
    private Acte acte;
    private CreneauReserve creneau;

    public RendezVous(int idRdv, Patient patient, Acte acte, CreneauReserve creneau) {
        this.idRdv = idRdv;
        this.patient = patient;
        this.acte = acte;
        this.creneau = creneau;
        this.dateReservation = LocalDate.now();
        this.dateRdv = creneau.getDate();
        this.etat = EN_ATTENTE;
    }

    public void valider() { etat = VALIDE; }
    public void annuler() { etat = ANNULE; }
    public boolean estAnnule() { return ANNULE.equals(etat); }

    @Override
    public String genererFiche() {
        return "===== FICHE DE RENDEZ-VOUS =====\n"
             + "Cabinet  : " + cabinet.service.Cabinet.NOM + "\n"
             + "Patient  : " + patient.getNom() + " " + patient.getPrenom() + "\n"
             + "Dentiste : Dr " + creneau.getDentiste().getNom() + "\n"
             + "Acte     : " + acte.getLibelle() + "\n"
             + "Date     : " + dateRdv + " a " + creneau.getHeureDebut() + "\n"
             + "Duree    : " + acte.getDuree() + " min\n"
             + "Tarif    : " + acte.getTarif() + " DH\n"
             + "Etat     : " + etat + "\n";
    }

    public int getIdRdv() { return idRdv; }
    public LocalDate getDateReservation() { return dateReservation; }
    public LocalDate getDateRdv() { return dateRdv; }
    public String getEtat() { return etat; }
    public Patient getPatient() { return patient; }
    public Acte getActe() { return acte; }
    public CreneauReserve getCreneau() { return creneau; }
}
