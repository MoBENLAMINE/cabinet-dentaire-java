package cabinet.service;

import cabinet.model.RendezVous;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;

/** Export de la fiche de rendez-vous en PDF avec Apache PDFBox. */
public class FichePDF {

    public static void exporter(RendezVous rdv, File fichier) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage();
            doc.addPage(page);
            try (PDPageContentStream flux = new PDPageContentStream(doc, page)) {
                flux.beginText();
                flux.setFont(PDType1Font.HELVETICA, 13);
                flux.setLeading(20);
                flux.newLineAtOffset(70, 720);
                // On reutilise le texte de l'interface Imprimable : une ligne PDF par ligne de fiche
                for (String ligne : rdv.genererFiche().split("\n")) {
                    flux.showText(ligne);
                    flux.newLine();
                }
                flux.endText();
            }
            doc.save(fichier);
        }
    }
}
