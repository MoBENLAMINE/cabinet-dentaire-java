package cabinet.service;

import java.io.*;

/**
 * Sauvegarde et chargement par SERIALISATION (flux d'objets, vu au chapitre E/S).
 * Tout l'objet Cabinet (et tout ce qu'il contient) est ecrit dans un seul fichier.
 */
public class Persistance {

    public static final String FICHIER = "cabinet.dat";

    public static void sauvegarder(Cabinet cabinet) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FICHIER))) {
            out.writeObject(cabinet);
        }
    }

    /** Si le fichier n'existe pas encore (premier lancement), on part des donnees de demo. */
    public static Cabinet charger() {
        File f = new File(FICHIER);
        if (!f.exists()) {
            return Cabinet.avecDonneesDemo();
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            return (Cabinet) in.readObject(); // casting
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Lecture impossible, donnees de demo chargees : " + e.getMessage());
            return Cabinet.avecDonneesDemo();
        }
    }
}
