package cabinet.service;

import cabinet.exception.AuthentificationException;
import cabinet.exception.CreneauIndisponibleException;
import cabinet.exception.DureeInsuffisanteException;
import cabinet.exception.ReservationException;
import cabinet.model.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Contient TOUTES les donnees du cabinet (c'est cet objet qu'on sauvegarde).
 * Les fenetres JavaFX appellent ses methodes.
 */
public class Cabinet implements Serializable {

    public static final String NOM = "Cabinet Dentaire EMI";

    private List<Utilisateur> utilisateurs = new ArrayList<>();
    private List<Dentiste> dentistes = new ArrayList<>();
    private List<Acte> actes = new ArrayList<>();
    private List<RendezVous> rendezVous = new ArrayList<>();
    private int prochainId = 1; // sauvegarde avec le reste : pas de doublon d'id

    public int nouvelId() { return prochainId++; }

    // ---------- Authentification ----------
    public Utilisateur connecter(String login, String pwd) throws AuthentificationException {
        for (Utilisateur u : utilisateurs) {
            if (u.authentifier(login, pwd)) return u;
        }
        throw new AuthentificationException();
    }

    // ---------- CRUD (ajout / suppression / affichage) ----------
    public void ajouterUtilisateur(Utilisateur u) { utilisateurs.add(u); }
    public void supprimerUtilisateur(Utilisateur u) { utilisateurs.remove(u); }

    /** Java 8 : stream + filter + map pour ne garder que les patients. */
    public List<Patient> getPatients() {
        return utilisateurs.stream()
                .filter(u -> u instanceof Patient)
                .map(u -> (Patient) u)
                .collect(Collectors.toList());
    }

    public void ajouterDentiste(Dentiste d) { dentistes.add(d); }
    public void supprimerDentiste(Dentiste d) { dentistes.remove(d); }
    public List<Dentiste> getDentistes() { return dentistes; }

    public void ajouterActe(Acte a) { actes.add(a); }
    public void supprimerActe(Acte a) { actes.remove(a); }
    public List<Acte> getActes() { return actes; }

    public Creneau ajouterCreneau(Dentiste d, LocalDate date, LocalTime debut, LocalTime fin, String type) {
        Creneau c = new Creneau(nouvelId(), date, debut, fin, type, d);
        d.ajouterCreneau(c);
        return c;
    }

    public List<RendezVous> getRendezVous() { return rendezVous; }

    // ---------- Reservation ----------
    public List<Creneau> getCreneauxLibres(Dentiste d) {
        return d.getPlanning().stream()
                .filter(Creneau::estLibre)       // reference de methode (Java 8)
                .collect(Collectors.toList());
    }

    /** Les 2 regles du sujet : pas de double reservation, et l'acte doit tenir dans le creneau. */
    public RendezVous reserver(Patient p, Acte a, Creneau c) throws ReservationException {
        if (!c.estLibre()) {
            throw new CreneauIndisponibleException();
        }
        if (!c.contient(a)) {
            throw new DureeInsuffisanteException(a.getDuree(), c.getDureeMinutes());
        }
        CreneauReserve cr = new CreneauReserve(c);
        RendezVous rdv = new RendezVous(nouvelId(), p, a, cr);
        cr.setRendezVous(rdv);
        c.getDentiste().remplacerCreneau(c, cr);
        rendezVous.add(rdv);
        return rdv;
    }

    /** Bonus : historique d'un patient. */
    public List<RendezVous> getHistorique(Patient p) {
        return rendezVous.stream()
                .filter(r -> r.getPatient() == p)
                .collect(Collectors.toList());
    }

    /** Bonus : nombre de rendez-vous par dentiste (Map = collection cle/valeur). */
    public Map<String, Long> statistiquesParDentiste() {
        return rendezVous.stream()
                .collect(Collectors.groupingBy(r -> r.getCreneau().getDentiste().getNom(),
                                               Collectors.counting()));
    }

    // ---------- Donnees de demonstration ----------
    public static Cabinet avecDonneesDemo() {
        Cabinet cab = new Cabinet();
        cab.ajouterUtilisateur(new Administrateur("admin", "admin123"));
        cab.ajouterUtilisateur(new Patient("ali", "1234", "AB123456", "Alaoui", "Ali",
                "Rabat, Agdal", "0612345678", LocalDate.of(2003, 5, 14)));
        cab.ajouterUtilisateur(new Patient("sara", "1234", "CD789012", "Bennani", "Sara",
                "Sale, Tabriquet", "0698765432", LocalDate.of(1999, 11, 2)));

        Dentiste d1 = new Dentiste(cab.nouvelId(), "Tazi", "Karim", "generaliste");
        Dentiste d2 = new Dentiste(cab.nouvelId(), "Idrissi", "Nadia", "orthodontiste");
        cab.ajouterDentiste(d1);
        cab.ajouterDentiste(d2);

        cab.ajouterActe(new Acte(cab.nouvelId(), "Detartrage", 30, 300));
        cab.ajouterActe(new Acte(cab.nouvelId(), "Extraction", 45, 500));
        cab.ajouterActe(new Acte(cab.nouvelId(), "Devitalisation", 60, 900));

        // Une semaine de creneaux de 30 min (9h-12h), + un creneau d'urgence d'1h par jour
        LocalDate lundi = LocalDate.of(2026, 10, 26);
        for (Dentiste d : cab.dentistes) {
            for (int jour = 0; jour < 5; jour++) {
                LocalDate date = lundi.plusDays(jour);
                for (int h = 9; h < 12; h++) {
                    cab.ajouterCreneau(d, date, LocalTime.of(h, 0), LocalTime.of(h, 30), Creneau.NORMAL);
                    cab.ajouterCreneau(d, date, LocalTime.of(h, 30), LocalTime.of(h + 1, 0), Creneau.NORMAL);
                }
                cab.ajouterCreneau(d, date, LocalTime.of(14, 0), LocalTime.of(15, 0), Creneau.URGENCE);
            }
        }
        return cab;
    }
}
