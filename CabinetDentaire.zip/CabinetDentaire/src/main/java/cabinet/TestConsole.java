package cabinet;

import cabinet.exception.AuthentificationException;
import cabinet.exception.ReservationException;
import cabinet.model.*;
import cabinet.service.Cabinet;
import cabinet.service.Persistance;

import java.io.File;
import java.util.List;

/** Tests en console (semaine 1 du planning de la prof), avant l'interface JavaFX. */
public class TestConsole {

    public static void main(String[] args) throws Exception {
        new File(Persistance.FICHIER).delete(); // on repart de zero pour le test
        Cabinet cab = Persistance.charger();

        // 1. Authentification
        Utilisateur admin = cab.connecter("admin", "admin123");
        Utilisateur u = cab.connecter("ali", "1234");
        System.out.println("Connectes : " + admin.getRole() + " et " + u.getRole());
        try {
            cab.connecter("ali", "faux");
        } catch (AuthentificationException e) {
            System.out.println("OK, refuse : " + e.getMessage());
        }

        // 2. Creneaux libres
        Patient ali = (Patient) u;
        Dentiste tazi = cab.getDentistes().get(0);
        List<Creneau> libres = cab.getCreneauxLibres(tazi);
        System.out.println("Creneaux libres de " + tazi + " : " + libres.size());

        // 3. Reservation valide
        Acte detartrage = cab.getActes().get(0);   // 30 min
        Creneau c = libres.get(0);                  // 30 min
        RendezVous rdv = cab.reserver(ali, detartrage, c);
        System.out.println("Reserve : " + rdv.getEtat() + ", libres maintenant : "
                + cab.getCreneauxLibres(tazi).size());

        // 4. Double reservation -> exception
        try {
            cab.reserver(ali, detartrage, tazi.getPlanning().get(0));
        } catch (ReservationException e) {
            System.out.println("OK, refuse : " + e.getMessage());
        }

        // 5. Acte trop long pour le creneau -> exception
        try {
            cab.reserver(ali, cab.getActes().get(2), tazi.getPlanning().get(1));
        } catch (ReservationException e) {
            System.out.println("OK, refuse : " + e.getMessage());
        }

        // 6. Validation par l'admin + fiche
        ((Administrateur) admin).validerRdv(rdv);
        System.out.println(rdv.genererFiche());

        // 7. Sauvegarde puis rechargement
        Persistance.sauvegarder(cab);
        Cabinet relu = Persistance.charger();
        RendezVous rdvRelu = relu.getRendezVous().get(0);
        System.out.println("Apres rechargement : " + relu.getRendezVous().size() + " rdv, etat = "
                + rdvRelu.getEtat() + ", creneau libre ? " + rdvRelu.getCreneau().estLibre());

        // 8. Annulation : le creneau redevient libre (polymorphisme de estLibre)
        rdv.annuler();
        System.out.println("Apres annulation, creneau libre ? " + rdv.getCreneau().estLibre());

        // 9. Statistiques (bonus)
        System.out.println("Rdv par dentiste : " + cab.statistiquesParDentiste());
    }
}
