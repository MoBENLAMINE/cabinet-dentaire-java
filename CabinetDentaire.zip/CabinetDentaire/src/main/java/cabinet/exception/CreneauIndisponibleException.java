package cabinet.exception;

/** Levee quand on essaie de reserver un creneau deja pris (double reservation). */
public class CreneauIndisponibleException extends ReservationException {
    public CreneauIndisponibleException() {
        super("Ce creneau est deja reserve.");
    }
}
