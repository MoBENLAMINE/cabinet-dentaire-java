package cabinet.exception;

/** Levee quand la duree de l'acte ne tient pas dans le creneau choisi. */
public class DureeInsuffisanteException extends ReservationException {
    public DureeInsuffisanteException(int dureeActe, long dureeCreneau) {
        super("L'acte dure " + dureeActe + " min mais le creneau ne fait que " + dureeCreneau + " min.");
    }
}
