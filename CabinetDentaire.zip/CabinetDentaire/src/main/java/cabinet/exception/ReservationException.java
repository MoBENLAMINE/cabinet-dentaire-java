package cabinet.exception;

/** Exception personnalisee (vu en cours : on herite de Exception). */
public class ReservationException extends Exception {
    public ReservationException(String message) {
        super(message);
    }
}
