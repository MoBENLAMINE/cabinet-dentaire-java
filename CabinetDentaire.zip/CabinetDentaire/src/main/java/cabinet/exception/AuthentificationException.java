package cabinet.exception;

public class AuthentificationException extends Exception {
    public AuthentificationException() {
        super("Login ou mot de passe incorrect.");
    }
}
