package cabinet.ui;

import cabinet.exception.ReservationException;
import cabinet.model.Acte;
import cabinet.model.Dentiste;
import cabinet.model.Patient;
import cabinet.model.RendezVous;
import cabinet.service.Cabinet;
import cabinet.service.Persistance;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Demo de la fenetre de reservation cote patient :
 * choisir dentiste + acte, cliquer un creneau vert, puis "Reserver".
 */
public class ReservationDemo extends Application {

    private Cabinet cabinet = Persistance.charger();

    @Override
    public void start(Stage stage) {
        Patient patient = cabinet.getPatients().get(0); // en vrai : le patient connecte

        ComboBox<Dentiste> choixDentiste = new ComboBox<>();
        choixDentiste.getItems().addAll(cabinet.getDentistes());
        ComboBox<Acte> choixActe = new ComboBox<>();
        choixActe.getItems().addAll(cabinet.getActes());
        choixActe.getSelectionModel().selectFirst();

        PlanningView planning = new PlanningView();
        choixDentiste.setOnAction(e -> planning.afficher(choixDentiste.getValue()));
        choixDentiste.getSelectionModel().selectFirst();
        planning.afficher(choixDentiste.getValue());

        Button reserver = new Button("Reserver");
        reserver.setOnAction(e -> {
            if (planning.getSelection() == null) {
                new Alert(Alert.AlertType.WARNING, "Choisissez d'abord un creneau vert.").showAndWait();
                return;
            }
            try {
                RendezVous rdv = cabinet.reserver(patient, choixActe.getValue(), planning.getSelection());
                Persistance.sauvegarder(cabinet);
                planning.afficher(planning.getDentiste());   // la couleur change tout de suite
                new Alert(Alert.AlertType.INFORMATION, rdv.genererFiche()).showAndWait();
            } catch (ReservationException ex) {
                new Alert(Alert.AlertType.ERROR, ex.getMessage()).showAndWait();
            } catch (java.io.IOException ex) {
                new Alert(Alert.AlertType.ERROR, "Sauvegarde impossible : " + ex.getMessage()).showAndWait();
            }
        });

        HBox barre = new HBox(10, new Label("Dentiste :"), choixDentiste,
                                  new Label("Acte :"), choixActe, reserver);
        VBox racine = new VBox(15, barre, new ScrollPane(planning));
        racine.setPadding(new Insets(15));

        stage.setTitle(Cabinet.NOM + " - Reservation");
        stage.setScene(new Scene(racine, 900, 560));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
