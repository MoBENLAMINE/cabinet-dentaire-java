package cabinet.ui;

import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.stage.Window;

/** Impression d'un element de l'interface (la fiche) avec PrinterJob de JavaFX. */
public class Impression {

    /** Ouvre la boite de dialogue d'impression puis imprime le noeud. Renvoie vrai si imprime. */
    public static boolean imprimer(Node fiche, Window fenetre) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) return false;               // aucune imprimante installee
        if (!job.showPrintDialog(fenetre)) return false; // l'utilisateur a annule
        boolean ok = job.printPage(fiche);
        if (ok) job.endJob();
        return ok;
    }
}
