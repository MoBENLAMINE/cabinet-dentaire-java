package cabinet.ui;

import cabinet.model.Creneau;
import cabinet.model.Dentiste;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Planning hebdomadaire d'un dentiste : jours en colonnes, heures en lignes.
 * Vert = libre, Rouge = occupe, Orange = urgence, Bleu = choisi par l'utilisateur.
 */
public class PlanningView extends GridPane {

    private Creneau selection;          // le creneau clique (en bleu)
    private Button boutonSelectionne;
    private Dentiste dentiste;

    public PlanningView() {
        setHgap(4);
        setVgap(4);
    }

    /** (Re)dessine toute la grille. A rappeler apres chaque reservation/validation/annulation. */
    public void afficher(Dentiste d) {
        this.dentiste = d;
        getChildren().clear();
        selection = null;
        boutonSelectionne = null;

        List<Creneau> planning = d.getPlanning();
        TreeSet<LocalDate> jours = new TreeSet<>();   // Set trie : chaque jour une seule fois
        TreeSet<LocalTime> heures = new TreeSet<>();
        for (Creneau c : planning) {
            jours.add(c.getDate());
            heures.add(c.getHeureDebut());
        }
        List<LocalDate> listeJours = new java.util.ArrayList<>(jours);
        List<LocalTime> listeHeures = new java.util.ArrayList<>(heures);

        DateTimeFormatter f = DateTimeFormatter.ofPattern("EEE dd/MM", Locale.FRENCH);
        for (int col = 0; col < listeJours.size(); col++) {
            add(new Label(listeJours.get(col).format(f)), col + 1, 0);   // en-tetes des jours
        }
        for (int lig = 0; lig < listeHeures.size(); lig++) {
            add(new Label(listeHeures.get(lig).toString()), 0, lig + 1); // en-tetes des heures
        }

        for (Creneau c : planning) {
            Button b = new Button(c.getHeureDebut() + "-" + c.getHeureFin());
            b.setPrefWidth(110);
            b.setStyle(styleDe(c));
            b.setDisable(!c.estLibre());                 // on ne clique pas un creneau occupe
            b.setOnAction(e -> choisir(c, b));           // expression lambda (Java 8)
            add(b, listeJours.indexOf(c.getDate()) + 1, listeHeures.indexOf(c.getHeureDebut()) + 1);
        }
    }

    private void choisir(Creneau c, Button b) {
        if (boutonSelectionne != null) {
            boutonSelectionne.setStyle(styleDe(selection));  // l'ancien reprend sa couleur
        }
        selection = c;
        boutonSelectionne = b;
        b.setStyle(couleur("#1E88E5"));                     // bleu : choisi
    }

    private String styleDe(Creneau c) {
        if (!c.estLibre()) return couleur("#E53935");        // rouge : occupe
        if (c.estUrgence()) return couleur("#FB8C00");       // orange : urgence
        return couleur("#43A047");                           // vert : libre
    }

    private String couleur(String hex) {
        return "-fx-background-color: " + hex + "; -fx-text-fill: white; -fx-opacity: 1;";
    }

    public Creneau getSelection() { return selection; }
    public Dentiste getDentiste() { return dentiste; }
}
